import React, { Component } from "react";
import './Register.css';
import ProjectCards from './ProjectCards.js';
class Register extends Component {
  constructor(props) {
    super(props);

    this.handleRegister = this.handleRegister.bind(this);
    this.handleFirstName  = this.handleFirstName.bind(this);
    this.handleLastName  = this.handleLastName.bind(this);
    this.handleAddress  = this.handleAddress.bind(this);
    this.handleEmail  = this.handleEmail.bind(this);
    this.handlePhoneNumber  = this.handlePhoneNumber.bind(this);
    this.handlePinCode  = this.handlePinCode.bind(this);
    this.handlePassword  = this.handlePassword.bind(this);
    this.handleWardno  = this.handleWardno.bind(this);
    this.validateFormValues = this.validateFormValues.bind(this);

    this.state = {
      firstname: "",
      lastname: "",
      address: "",
      email: "",
      phoneno: "",
      pincode: "",
      password: "",
      wardno:"",
      firstnameValidationError:'',
      lastnameValidationError:'',
      addressValidationError:'',
      emailValidationError:'',
      phonenoValidationError: '',
      pincodeValidationError:'',
      passwordValidationError:'',
      wardnoValidationError:'',
      emailValidationErrorr:'',
      phoneNoValidationErrorr: '',
      error:'',
      done:'',
    };
  }

  handleFirstName(e) {
    this.setState({ firstname: e.target.value });
    // console.log(this.state.firstname);
  }
  handleLastName(e) {
    this.setState({ lastname: e.target.value });
    // console.log(this.state.lastname)
  }
  handleAddress(e) {
    this.setState({ address: e.target.value });
    // console.log(this.state.address)
  }

  handleEmail(e) {
    this.setState({ email: e.target.value });
    // console.log(this.state.email)
  }
  handlePhoneNumber(e) {
    this.setState({ phoneno: e.target.value });
    // console.log(this.state.phoneno)
  }
  handlePinCode(e) {
    this.setState({ pincode: e.target.value });
    // console.log(this.state.pincode)
  }
  handlePassword(e) {
    this.setState({ password: e.target.value });
    // console.log(this.state.password)
  }
  handleWardno(e) {
    this.setState({ wardno: e.target.value });
    // console.log(this.state.wardno)
  }

  validateFormValues () {
    if((!this.state.lastname)&&(!this.state.firstname)&&(!this.state.address)&&(!this.state.email)&&(!this.state.phoneno)&&(!this.state.pincode)&&(!this.state.wardno))
    // if(!this.state.firstname)
     {
        this.setState({
            firstnameValidationError: 'First Name should not be null'
        });
        this.setState({
            lastnameValidationError: 'Last Name should not be null'
        });
        this.setState({
            addressValidationError: 'Address should not be null'
        });
        this.setState({
            emailValidationError: 'Email should not be null'
        });
        this.setState({
            phonenoValidationError: 'Phone Number should not be null'
        });
        this.setState({
            pincodeValidationError: 'Pincode should not be null'
        });
        this.setState({
            wardnoValidationError: 'Ward Number should not be null'
        });
        this.setState({
            passwordValidationError: 'Password should not be null'
        });
        return false;
    }
    else if(!this.state.lastname) {
        this.setState({
            lastnameValidationError: 'Last Name should not be null'
        });
        return false;
    }
    else if(!this.state.address) {
        this.setState({
            addressValidationError: 'Address should not be null'
        });
        return false;
    }
    else if(!this.state.email) {
      this.setState({
            emailValidationError: 'Email should not be null'
        });
        return false;
    }
    else if(!this.state.phoneno) {
      this.setState({
        phonenoValidationError: 'Phone Number should not be null'
      });
      return false;
    }
    else if(!this.state.pincode) {
      this.setState({
        pincodeValidationError: 'Pincode should not be null'
      });
      return false;
    }
    else if(!this.state.wardno) {
      this.setState({
        wardnoValidationError: 'Ward Number should not be null'
      });
      return false;
    }
    return true;
  }
  

  handleRegister() {
    var validated = this.validateFormValues();
    if(validated) 
    {

      fetch("http://127.0.0.1:8000/zerowaste/houseowner/signup/", {
      headers: { "Content-Type": "application/json" },
      method: "POST",
      body: JSON.stringify({
        firstname: this.state.firstname,
        lastname: this.state.lastname,
        address: this.state.address,
        email: this.state.email,
        phoneno: this.state.phoneno,
        pincode:this.state.pincode,
        password: this.state.password,
        wardno:this.state.wardno,
        
      })
      
    })
      .then(response => {
        console.log("json response1: ", response);
        return response.json();
      })
      .then(resJson => {
        console.log("json response2: ", resJson);
        this.setState({
            emailValidationErrorr: resJson.data.email[0],
            phoneNoValidationErrorr: resJson.data.phoneno[0],
          })

      })
      .catch(err => {
        
        console.log(err);
      });
      this.setState({
        done: '1'
      });
      
      

    }
    console.log("Enter Valid Data")
    this.state.error = "";

    //   console.log(this.state.firstnameValidationError,this.state.pincode); 
  }

  render() {
    return (
      <div className="register">
        <h2 className="registerhead">HouseOwner Registration</h2>
        <h5 className="itemm">First Name :<input className="inputarea" type="text" name="firstName" onChange={this.handleFirstName} /></h5>
        {this.state.firstnameValidationError && <div className="errormessage">{this.state.firstnameValidationError}</div>}
        <h5 className="itemm">Last Name :<input className="inputarea"  type="text" name="lastname" onChange={this.handleLastName} /></h5>
        {this.state.lastnameValidationError && <div className="errormessage">{this.state.lastnameValidationError}</div>}
        
        <h5 className="itemm">Address : <input  className="inputarea" type="text" name="address" onChange={this.handleAddress} /></h5>
        {this.state.addressValidationError && <div className="errormessage">{this.state.addressValidationError}</div>}
        
        <h5 className="itemm">Email ID : <input className="inputarea" type="text" name="email" onChange={this.handleEmail} /></h5>
        {this.state.emailValidationErrorr && <div className="errormessage">{this.state.emailValidationErrorr}</div>}
        {this.state.emailValidationError && <div className="errormessage">{this.state.emailValidationError}</div>}
    
        <h5 className="itemm">Phone Number : <input className="inputarea" type="text" name="phoneno" onChange={this.handlePhoneNumber} /></h5>
        {this.state.phoneNoValidationErrorr && <div className="errormessage">{this.state.phoneNoValidationErrorr}</div>}
        {this.state.phonenoValidationError && <div className="errormessage">{this.state.phonenoValidationError}</div>}
        
        <h5 className="itemm">Pincode : <input className="inputarea" type="text" name="pincode" onChange={this.handlePinCode} /></h5>
        {this.state.pincodeValidationError && <div className="errormessage">{this.state.pincodeValidationError}</div>}
        
        <h5 className="itemm">Password : <input type="text" name="password" onChange={this.handlePassword} /></h5>
        {this.state.passwordValidationError && <div className="errormessage">{this.state.passwordValidationError}</div>}
        
        <h5 className="itemm">Ward Number : <input type="text" name="wardno" onChange={this.handleWardno} /></h5>
        {this.state.wardnoValidationError && <div className="errormessage">{this.state.wardnoValidationError}</div>}
        
        <button onClick={this.handleRegister}>Submit</button>
        
      </div>
    );
  }
}

export default Register;
